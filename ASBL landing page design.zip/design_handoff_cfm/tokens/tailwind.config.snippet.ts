/**
 * CFM ASBL — extrait de tailwind.config.ts (à fusionner dans theme.extend)
 * Deux palettes : `site-*` (public + portail, bleu institutionnel) et `admin-*` (console, teal).
 * Remplace progressivement les tokens `cfm-*`.
 */
import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        // ---- Public & Portail (institutionnel, éditorial) ----
        site: {
          ink: "#14171c",
          muted: "#4a4d54",
          "muted-2": "#6b6b63",
          hairline: "#e6e6e2",
          surface: "#f6f8fc",
          primary: "#14418a",
          "primary-dark": "#0f367a",
          deep: "#0b1a38",      // footer, sections témoignages
          light: "#7aa7f5",
          pale: "#eaf0fb",       // fonds d'icônes
          live: "#e23b3b",
          success: "#1f8a5b",
        },
        // ---- Admin (console de travail, teal) ----
        admin: {
          bg: "#f6f7f9",
          sidebar: "#16181d",
          "sidebar-active": "#22252c",
          ink: "#1c1c1a",
          muted: "#6b7076",
          "muted-2": "#8b9099",
          border: "#e6e8ec",
          accent: "#127d73",
          "accent-dark": "#0e6b62",
          deep: "#12325f",
          "warn-fg": "#b7791f", "warn-bg": "#fef3e2",
          "ok-fg": "#127d73",   "ok-bg": "#e3f3f0",
          "info-fg": "#2563aa", "info-bg": "#e7effa",
          "danger-fg": "#c0362c", "danger-bg": "#fbeae8",
        },
      },
      fontFamily: {
        // Public / Portail
        serif: ["var(--font-newsreader)", "Georgia", "serif"],
        sans: ["var(--font-archivo)", "system-ui", "sans-serif"],
        // Admin
        display: ["var(--font-space-grotesk)", "system-ui", "sans-serif"],
        ui: ["var(--font-plex-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-plex-mono)", "ui-monospace", "monospace"],
      },
      borderRadius: {
        // Public/Portail = coins nets → utiliser rounded-none.
        admin: "8px",          // cartes admin
        "admin-ctrl": "7px",   // contrôles admin
      },
      boxShadow: {
        "site-hover": "0 18px 40px rgba(20,40,90,.13)",
        "admin-drawer": "-16px 0 48px rgba(12,14,18,.14)",
      },
      maxWidth: {
        site: "1240px",
        portal: "1140px",
      },
    },
  },
  plugins: [],
};

export default config;
