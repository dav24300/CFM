# Handoff — Refonte CFM ASBL : Site public, Portail communautaire & Admin

## Vue d'ensemble

Ce package contient la refonte design complète de **CFM ASBL (Cri de Familles Militaires)**, une association congolaise (RDC) défendant les droits des dépendants des militaires. Il couvre trois surfaces :

1. **Site public** — pages institutionnelles (accueil, axes, actions, plaidoyer, pétitions, live, s'engager, presse, contact, à propos).
2. **Portail communautaire membre** — application connectée (fil d'annonces, demandes d'aide, messagerie, entraide, ressources, événements, famille, dons, pétitions, médias, profil, coordination) avec **rôles** (Famille / Bénévole / Coordinateur).
3. **Admin** — console de gestion back-office (13 sections) avec **édition détaillée** (formulaires slide-over, aperçus live, upload).

Cible d'intégration : le dépôt existant **Next.js 15 (App Router) + Tailwind CSS 3.4** (`CFM/`).

---

## À propos des fichiers de design

Les fichiers du dossier `design-files/` sont des **références de design réalisées en HTML** (`.dc.html`) — des prototypes montrant l'apparence et le comportement attendus, **pas du code de production à copier tel quel**. La tâche est de **recréer ces designs dans l'environnement existant du codebase** (React/Next.js + Tailwind), en réutilisant ses conventions (composants `src/components/`, `next/image`, `next/font`, i18n, repositories).

Format des fichiers : ce sont des « Design Components » (styles inline, JS vanilla). En production, convertir en composants React/Tailwind idiomatiques. **Ne pas embarquer le HTML directement.**

## Fidélité

**Haute fidélité (hi-fi).** Couleurs, typographies, espacements et interactions sont définitifs. Recréer l'UI au pixel près avec les libs du codebase (Tailwind, Lucide, `next/font`, Framer Motion pour les animations — cf. `WEBDESIGN.md`).

---

## Deux design systems distincts

La refonte introduit **deux systèmes visuels** (remplaçant l'ancien navy/or/crème `cfm-*`) :

### A. Design System « Public & Portail » (institutionnel, éditorial)
Fond blanc pur, **coins nets (radius 0)**, serif éditorial + grotesque.

| Token | Valeur |
|---|---|
| `--fg` encre | `#14171c` |
| texte atténué | `#4a4d54` / `#6b6b63` |
| fond | `#ffffff` |
| surface | `#f6f8fc` |
| hairline / bordure | `#e6e6e2` |
| **primaire (accent)** | `#14418a` |
| primaire hover | `#0f367a` |
| bleu profond (footer, témoignages) | `#0b1a38` |
| bleu clair | `#7aa7f5` |
| pâle (fonds d'icônes) | `#eaf0fb` |
| « live » rouge | `#e23b3b` |
| succès | `#1f8a5b` |

- **Typo titres** : `Newsreader` (serif, weights 400/500/600, italique pour accents).
- **Typo UI/corps** : `Archivo` (400/500/600/700).
- **Mono** (labels techniques, IDs) : `ui-monospace, Menlo`.
- **Coins** : `0` (carrés/éditorial). Bordures 1px `#e6e6e2`.
- **Ombres** : discrètes, `0 18px 40px rgba(20,40,90,.13)` au survol des cartes.

### B. Design System « Admin » (console de travail)
Sidebar graphite + espace clair, **coins arrondis 8px**, accent teal.

| Token | Valeur |
|---|---|
| espace de travail | `#f6f7f9` |
| sidebar | `#16181d` (item actif `#22252c`, bordure gauche `#127d73`) |
| encre | `#1c1c1a` |
| texte atténué | `#6b7076` / `#8b9099` |
| bordure | `#e6e8ec` |
| carte | `#ffffff`, radius **8px** |
| **accent (teal)** | `#127d73` (hover `#0e6b62`) |
| bleu profond (bandeaux) | `#12325f` |
| statut « warn » | texte `#b7791f` / fond `#fef3e2` |
| statut « ok » | texte `#127d73` / fond `#e3f3f0` |
| statut « info » | texte `#2563aa` / fond `#e7effa` |
| statut « danger » | texte `#c0362c` / fond `#fbeae8` |

- **Typo display / KPIs / titres de section** : `Space Grotesk` (500/600/700).
- **Typo UI** : `IBM Plex Sans` (400/500/600/700).
- **Typo données / IDs** : `IBM Plex Mono` (400/500).
- **Coins** : contrôles 6–7px, cartes 8px.

> Ces deux systèmes remplacent les tokens Tailwind `cfm-navy/gold/warm/cream/earth` et le pairing `Playfair Display + Nunito`. Mettre à jour `tailwind.config.ts` + `next/font` en conséquence (voir « Intégration » plus bas).

---

## Correspondance maquettes → routes Next.js

### Site public — `src/app/(site)/`
| Maquette (`design-files/`) | Route existante | Action |
|---|---|---|
| `Accueil.dc.html` | `/` (`page.tsx`) | Refonte hero parallaxe + sections |
| `A-propos.dc.html` | `/a-propos` | Refonte |
| `Axes.dc.html` | `/axes` | Transformer en **page index** |
| `Axe-social/economique/education/environnement/sante.dc.html` | **NOUVEAU** `/axes/[slug]` | Créer route dynamique (5 axes) |
| `Actions.dc.html` | `/actions` | Refonte (grille 26 provinces + filtre) |
| `Plaidoyer.dc.html` | `/plaidoyer` | Refonte |
| `Petitions.dc.html` / `Petition-detail.dc.html` | `/petitions`, `/petitions/[slug]` | Refonte |
| `Live.dc.html` / `Live-detail.dc.html` | `/live`, `/live/[slug]` | Refonte |
| `S-engager.dc.html` | `/s-engager` | Refonte (adhésion, don Mobile Money, transparence) |
| `Presse.dc.html` | `/presse` | Refonte |
| `Contact.dc.html` | `/contact` | Refonte (demande d'aide `#aide` + contact général) |
| `Actualite-detail.dc.html` | `/actualites/[slug]` | Refonte |
| `SiteHeader.dc.html` / `SiteFooter.dc.html` | `Header.tsx` / `Footer.tsx` | En-tête (menu déroulant « Nos axes ») + pied de page (liens sociaux réels) |

### Portail membre — NOUVEAU groupe de routes (ex. `src/app/(portail)/portail/`)
Layout partagé (sidebar + topbar) = `PortalShell` (cf. `portal-shell.js`). Contexte de rôle via session/claims.

| Maquette | Route suggérée | Rôles voyant l'écran |
|---|---|---|
| `Portail-accueil.dc.html` | `/portail` (fil d'annonces) | tous |
| `Portail-aide.dc.html` | `/portail/aide` | **Famille** |
| `Portail-messages.dc.html` | `/portail/messages` | tous |
| `Portail-entraide.dc.html` | `/portail/entraide` | tous (modéré) |
| `Portail-medias.dc.html` | `/portail/medias` | tous |
| `Portail-ressources.dc.html` | `/portail/ressources` | tous |
| `Portail-evenements.dc.html` | `/portail/evenements` | tous |
| `Portail-famille.dc.html` | `/portail/famille` | **Famille** |
| `Portail-dons.dc.html` | `/portail/dons` | tous |
| `Portail-petitions.dc.html` | `/portail/petitions` | tous |
| `Portail-profil.dc.html` | `/portail/profil` | tous |
| `Portail-coordination.dc.html` | `/portail/coordination` | **Coordinateur** |

Connexion / inscription (`Membre-connexion.dc.html`, `Membre-inscription.dc.html`, `Membre-mot-de-passe.dc.html`) redirigent vers `/portail` après authentification.

### Admin — `src/app/admin/dashboard/`
`Admin.dc.html` = refonte de `AdminDashboard.tsx` avec le **DS Admin (teal)**. 13 sections déjà mappées sur les panneaux existants (`AdminSidebar.tsx` → mêmes ids : overview, inbox, content, territory, community, donations, live, design, identity, pages, i18n, partners, audit). Ajouter l'**éditeur slide-over** (voir plus bas).

---

## Écrans clés — détails

### Site public — Accueil (`Accueil.dc.html`)
- **Hero** plein écran (min-height `min(760px,90vh)`), fond `#0f1622`, image/vidéo FIKIN + grille technique + overlay dégradé. **Parallaxe au curseur** (couches `data-depth` 0.045 / 0.09 / -0.035), **ken-burns** (scale 1.06→1.16, 18s), titre révélé mot par mot (`fade-up` staggered), **bouton magnétique**. Kicker `#9fbdf0`, H1 Newsreader `clamp(40px,6vw,66px)` blanc.
- **Bandeau marquee** défilant (verbes d'action), fond `#14418a`.
- **Bande de stats** : compteurs animés (count-up) 2018 / 26 / FIKIN.
- **Mission** (split image/texte), **5 axes** (cartes cliquables → pages d'axes, survol : `translateY(-6px)` + shadow + bordure accent), **Live** (replay), **Témoignages** (fond `#0b1a38`), **CTA + newsletter**.
- Zones image = placeholders rayés balisés (monospace) → remplacer par `next/image` + vrais médias FIKIN.

### Page d'axe dédiée (`Axe-*.dc.html`)
Hero (icône + « Axe 0X · Nom »), sous-nav entre les 5 axes (sticky), section « L'enjeu », **3 tuiles d'impact** (dont chiffres réels : 2018, 26 provinces, objectif pétition), **4 priorités** (depuis `AXES[].details` de `constants.ts`), « Sur le terrain » (actions/campagnes/pétitions réelles du seed), galerie, témoignage/citation fondateur, triple CTA.

### Portail — Fil d'annonces (`Portail-accueil.dc.html`)
- **Coquille** : sidebar graphite `#0b1a38` (logo, bloc utilisateur cliquable → profil, nav + badges, sélecteur de rôle démo, déconnexion), topbar (recherche, langues FR/EN/LN/SW, notifications). Sidebar **sticky ≥1000px, tiroir <1000px** (scrim).
- **Feed** (2 colonnes ≥900px) : composer entraide (modéré), cartes annonces CFM (dont **vidéo YouTube** avec lecture inline, **photo de couverture** = zone de dépôt), post d'entraide « Modéré ». Rail : notifications, prochains événements, alertes SMS/WhatsApp (toggles).
- **Adaptation par rôle** (`data-role-only`) : Famille → « Nouvelle demande d'aide » ; Bénévole → « Proposer mon aide » + carte « Missions bénévoles » ; Coordinateur → « Diffuser une annonce » + bande de KPIs de province.

### Admin (`Admin.dc.html`)
- Sidebar 13 sections (badges de tâches), topbar (recherche, rafraîchir, admin, déconnexion), navigation client instantanée.
- Panneaux : **cartes KPI**, **tableaux de données** (header uppercase, lignes bordées, actions par ligne), **badges de statut**, filtres/onglets.
- **Éditeur détaillé (slide-over droit, largeur `min(640px,96vw)`)** ouvert par « Modifier » (pré-rempli) / « + Nouveau » (vierge) ; **aperçu live** (Contenu : badge+titre+extrait ; Live : embed YouTube au collage de l'ID) ; champs typés : texte, select, province, date, textarea, **image (drop zone)**, **pièces jointes**, **toggle**. « Supprimer » → retrait de ligne + toast. Enregistrer → toast de confirmation.

---

## Interactions & comportements

- **Animations** (public/portail) : parallaxe curseur (hero), ken-burns, reveal au scroll (IntersectionObserver, `opacity/translateY`), compteurs count-up, marquee, boutons magnétiques, frises qui se dessinent (`scaleX`), respect **`prefers-reduced-motion`**. → En React, utiliser **Framer Motion** (déjà prévu dans `WEBDESIGN.md`) + IntersectionObserver.
- **Portail** : sélecteur de rôle bascule les éléments `data-role-only` ; carrousels ; toggles SMS/WhatsApp ; messagerie (envoi de message ajoute une bulle) ; chat live ; sondage.
- **Admin** : switch de section, slide-over éditeur, aperçus live, suppression de ligne, toasts, tiroir responsive.
- **Vidéo** : players YouTube — brancher l'ID réel (attribut `data-yt` dans les maquettes) sur les embeds `youtube.com/embed/{id}`.
- **Responsive** : breakpoints portail/admin à **1000px** (sidebar → tiroir), grilles publiques à 900/820/720/640/560px.

## State management (React)
- **Portail** : rôle utilisateur (session), état de la navigation, données par écran (demandes, messages, événements, dons…) via les repositories/API existants. Sidebar/topbar en layout partagé.
- **Admin** : section active, bundle admin (`loadAdminBundle()` existant), état de l'éditeur (entité en cours, mode new/edit), toasts. Réutiliser `AdminToastContext`.
- Les formulaires (adhésion, don, contact, aide, signature, éditeurs admin) sont branchés sur les routes API existantes (`src/app/api/**`).

## Design tokens — récapitulatif
Voir les deux tableaux « Design systems » ci-dessus. Échelle d'espacement observée : 8 / 12 / 14 / 16 / 20 / 22 / 24 / 28 / 32 / 44 / 56 / 88 / 104 px. Conteneurs : public `max-width:1240px`, portail `1140px`, admin fluide. Padding sections publiques `104px` vertical.

## Assets
- **Aucune photo réelle** dans les maquettes : zones balisées (placeholders rayés monospace) et **`<image-slot>`** (glisser-déposer) marquent l'emplacement des vrais médias. Voir le plan média de `CFM/WEBDESIGN.md` (§5) pour l'inventaire et les formats (WebP, tailles, poids 3G).
- **Icônes** : SVG inline type Lucide → utiliser **`lucide-react`** (déjà dans le codebase).
- **Polices** : charger via `next/font/google` — Newsreader, Archivo (public/portail) ; Space Grotesk, IBM Plex Sans, IBM Plex Mono (admin).
- **Liens sociaux réels** : facebook.com/cfmasbl, x.com/cfmasbl, youtube.com/@cfmasbl, linkedin.com/company/cfmasbl.
- **Contenu** : tiré de `CFM/src/lib/constants.ts` (SITE, AXES, PROVINCES_RDC, MEMBERSHIP_TYPES) et `CFM/data/store.seed.json` (news, campaigns, studies, actions, testimonials, petitions, live_events, partners).

## Intégration — étapes recommandées
1. **Tokens** : ajouter deux palettes à `tailwind.config.ts` (`site-*` / `admin-*`) + polices via `next/font`. Déprécier progressivement `cfm-*`.
2. **Public** : refondre les pages `(site)/*` ; créer la route dynamique `/axes/[slug]`.
3. **Portail** : nouveau groupe de routes + layout `PortalShell` + garde de rôle (middleware/session).
4. **Admin** : appliquer le DS admin à `AdminDashboard` + composants `admin/ui/*` (data-table, badges, boutons) ; ajouter le slide-over éditeur branché sur les mutations API existantes.
5. **Animations** : Framer Motion + IntersectionObserver, avec `prefers-reduced-motion`.
6. **Médias** : `next/image` + pipeline WebP (WEBDESIGN §5), remplacer les `<image-slot>`.

## Fichiers (dans `design-files/`)
Toutes les maquettes `.dc.html` du site, du portail et de l'admin, plus `portal-shell.js` (coquille portail) et `image-slot.js` (zone de dépôt d'image). Ouvrir chaque `.dc.html` dans un navigateur pour voir le rendu et les interactions de référence.
