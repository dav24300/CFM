// Portail CFM — coquille partagée (sidebar + comportements). Appelée depuis componentDidMount de chaque page.
(function () {
  var NAV = [
    ['accueil', 'Portail-accueil.dc.html', "Fil d'annonces", '<path d="M4 5h16M4 12h16M4 19h10"/>', null, null],
    ['aide', 'Portail-aide.dc.html', "Mes demandes d'aide", '<path d="M4 4h16v12H7l-3 3z"/>', null, 'famille'],
    ['messages', 'Portail-messages.dc.html', 'Messagerie', '<path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-6.4A8 8 0 1 1 21 12z"/>', '2', null],
    ['entraide', 'Portail-entraide.dc.html', 'Entraide', '<path d="M17 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9.5" cy="7" r="3.5"/><path d="M22 20v-2a4 4 0 0 0-3-3.8"/>', null, null],
    ['medias', 'Portail-medias.dc.html', 'Médias & galerie', '<rect x="3" y="5" width="18" height="14"/><circle cx="9" cy="11" r="2"/><path d="M21 17l-5-5-6 6"/>', null, null],
    ['ressources', 'Portail-ressources.dc.html', 'Ressources & démarches', '<path d="M4 5a2 2 0 0 1 2-2h9l5 5v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M14 3v5h5"/>', null, null],
    ['evenements', 'Portail-evenements.dc.html', 'Événements', '<rect x="3" y="4" width="18" height="17"/><path d="M3 9h18M8 2v4M16 2v4"/>', null, null],
    ['famille', 'Portail-famille.dc.html', 'Ma famille', '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>', null, 'famille'],
    ['dons', 'Portail-dons.dc.html', 'Dons & reçus', '<path d="M20.8 8.6a3 3 0 0 0-4.2 0l-.6.6-.6-.6a3 3 0 1 0-4.2 4.2l4.8 4.8 4.8-4.8a3 3 0 0 0 0-4.2z"/>', null, null],
    ['petitions', 'Portail-petitions.dc.html', 'Pétitions', '<path d="M6 3h9l4 4v14H6z"/><path d="M9 13h6M9 17h4"/>', null, null],
    ['coordination', 'Portail-coordination.dc.html', 'Coordination', '<path d="M3 12h4l3 8 4-16 3 8h4"/>', null, 'coordinateur']
  ];
  function icon(p) { return '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + p + '</svg>'; }

  window.PortalShell = function () {
    var root = document.getElementById('portal');
    if (!root || root.getAttribute('data-shell') === '1') return;
    root.setAttribute('data-shell', '1');
    var active = root.getAttribute('data-active') || '';

    var navHtml = NAV.map(function (n) {
      var badge = n[4] ? '<span style="margin-left:auto;background:#e23b3b;color:#fff;font:700 10px/1 Archivo;padding:3px 6px">' + n[4] + '</span>' : '';
      var extra = n[5] ? ' data-role-only="' + n[5] + '" ' : '';
      var top = n[0] === 'coordination' ? 'margin-top:6px;border-top:1px solid rgba(255,255,255,.08);' : '';
      var on = n[0] === active;
      var st = 'display:flex;align-items:center;gap:12px;padding:12px 22px;text-decoration:none;border-left:3px solid ' + (on ? '#7aa7f5' : 'transparent') + ';' + top + 'color:' + (on ? '#fff' : 'rgba(255,255,255,.82)') + ';background:' + (on ? '#12325f' : 'transparent') + ';';
      return '<a' + extra + ' href="' + n[1] + '" style="' + st + '">' + icon(n[3]) + n[2] + badge + '</a>';
    }).join('');

    var sidebar = document.createElement('aside');
    sidebar.id = 'p-side';
    sidebar.style.cssText = 'position:sticky;top:0;z-index:80;width:262px;flex:none;height:100vh;overflow-y:auto;background:#0b1a38;color:#fff;display:flex;flex-direction:column';
    sidebar.innerHTML =
      '<div style="padding:22px 22px 18px;border-bottom:1px solid rgba(255,255,255,.1)"><a href="Accueil.dc.html" style="display:flex;align-items:center;gap:11px;text-decoration:none"><span style="display:flex;align-items:center;justify-content:center;width:34px;height:34px;background:#fff;color:#0b1a38;flex:none"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 5v6c0 5 3.5 8.5 8 11 4.5-2.5 8-6 8-11V5l-8-3z"/></svg></span><span style="font:600 16px/1 Newsreader,serif;color:#fff">Portail CFM</span></a></div>' +
      '<a href="Portail-profil.dc.html" style="padding:18px 22px;border-bottom:1px solid rgba(255,255,255,.1);display:flex;align-items:center;gap:12px;text-decoration:none"><span style="width:42px;height:42px;flex:none;background:#12325f;color:#fff;display:flex;align-items:center;justify-content:center;font:600 15px/1 Newsreader,serif">MK</span><span style="min-width:0;flex:1"><span style="display:block;font:600 14px/1.2 Archivo;color:#fff">Marie Kabongo</span><span id="role-badge" style="display:block;margin-top:3px;font:500 11px/1.2 Archivo;color:#7aa7f5">Famille militaire</span></span><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.5)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></a>' +
      '<nav class="p-nav" style="padding:12px 0;flex:1;display:flex;flex-direction:column;gap:1px;font:500 14px/1 Archivo">' + navHtml + '</nav>' +
      '<div style="padding:16px 22px;border-top:1px solid rgba(255,255,255,.1)"><label style="display:block;font:500 11px/1 Archivo;letter-spacing:.05em;text-transform:uppercase;color:rgba(255,255,255,.45);margin-bottom:7px">Rôle (démo)</label><select id="role-switch" style="width:100%;background:#12325f;color:#fff;border:1px solid rgba(255,255,255,.15);padding:9px 10px;font:500 13px/1 Archivo"><option value="famille">Famille militaire</option><option value="benevole">Bénévole</option><option value="coordinateur">Coordinateur provincial</option></select><a href="Accueil.dc.html" style="display:flex;align-items:center;gap:10px;margin-top:14px;font:500 13px/1 Archivo;color:rgba(255,255,255,.6);text-decoration:none"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5V3h4M14 17l5-5-5-5M19 12H9"/></svg>Déconnexion</a></div>';

    var scrim = document.createElement('div');
    scrim.id = 'p-scrim';
    scrim.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(11,26,56,.4);z-index:70';

    root.insertBefore(sidebar, root.firstChild);
    root.insertBefore(scrim, root.firstChild);

    var applyRole = function (role) {
      root.setAttribute('data-role', role);
      root.querySelectorAll('[data-role-only]').forEach(function (el) {
        var show = el.getAttribute('data-role-only').split(',').indexOf(role) >= 0;
        el.style.display = show ? (el.getAttribute('data-disp') || 'flex') : 'none';
      });
      var b = document.getElementById('role-badge');
      if (b) { var m = { famille: 'Famille militaire', benevole: 'Bénévole', coordinateur: 'Coordinateur provincial' }; b.textContent = m[role] || role; }
    };
    var sel = document.getElementById('role-switch');
    if (sel) { sel.value = root.getAttribute('data-role') || 'famille'; sel.addEventListener('change', function () { applyRole(sel.value); }); applyRole(sel.value); }

    var burger = document.getElementById('p-burger');
    var openDrawer = function (o) { sidebar.style.transform = o ? 'translateX(0)' : ''; scrim.style.display = o ? 'block' : 'none'; };
    if (burger) burger.addEventListener('click', function () { openDrawer(true); });
    scrim.addEventListener('click', function () { openDrawer(false); });
    var resp = function () {
      var wide = window.innerWidth >= 1000;
      if (wide) { sidebar.style.position = 'sticky'; sidebar.style.transform = ''; sidebar.style.transition = ''; }
      else { sidebar.style.position = 'fixed'; if (!sidebar.style.transform) sidebar.style.transform = 'translateX(-105%)'; sidebar.style.transition = 'transform .3s ease'; }
      if (burger) burger.style.display = wide ? 'none' : 'inline-flex';
      if (wide) scrim.style.display = 'none';
    };
    resp(); window.addEventListener('resize', resp);

    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.style.opacity = '1'; e.target.style.transform = 'none'; io.unobserve(e.target); } }); }, { threshold: 0.05 });
    document.querySelectorAll('[data-rev]').forEach(function (el) { io.observe(el); });
    document.querySelectorAll('[data-lang]').forEach(function (b) { b.addEventListener('click', function () { document.querySelectorAll('[data-lang]').forEach(function (x) { x.style.background = 'transparent'; x.style.color = '#6b6b63'; }); b.style.background = '#eaf0fb'; b.style.color = '#14418a'; }); });
  };
})();
